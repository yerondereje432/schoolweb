import { createClient } from "@/lib/supabase/server";
import PageHero from "@/components/public/page-hero";
import ContactForm from "@/components/public/contact-form";
import { Phone, Mail, MapPin } from "lucide-react";

export default async function ContactPage() {
  const supabase = await createClient();
  const { data: contact } = await supabase
    .from("contact_info")
    .select("*")
    .eq("id", 1)
    .single();

  const hasMap = contact?.map_lat && contact?.map_lng;

  return (
    <div>
      <PageHero
        icon={<Mail size={28} />}
        eyebrow="Get in Touch"
        title="Contact Us"
        subtitle="We’d love to hear from you — reach out with any questions."
      />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-16 grid grid-cols-1 md:grid-cols-2 gap-12">
        <div>
          <h2 className="text-lg font-semibold text-husss-green-950 mb-5">
            Get in Touch
          </h2>

          <div className="space-y-4 mb-8">
            {contact?.address_en && (
              <div className="flex items-start gap-3">
                <MapPin className="text-husss-green-600 mt-0.5 shrink-0" size={18} />
                <p className="text-gray-600 text-sm">{contact.address_en}</p>
              </div>
            )}
            {contact?.phone_primary && (
              <div className="flex items-center gap-3">
                <Phone className="text-husss-green-600 shrink-0" size={18} />
                <p className="text-gray-600 text-sm">
                  {contact.phone_primary}
                  {contact.phone_secondary ? `, ${contact.phone_secondary}` : ""}
                </p>
              </div>
            )}
            {contact?.email_primary && (
              <div className="flex items-center gap-3">
                <Mail className="text-husss-green-600 shrink-0" size={18} />
                <p className="text-gray-600 text-sm">{contact.email_primary}</p>
              </div>
            )}
            {!contact?.address_en && !contact?.phone_primary && !contact?.email_primary && (
              <p className="text-sm text-gray-400 italic">
                Contact details will appear here once added by school
                administration.
              </p>
            )}
          </div>

          {hasMap && (
            <div className="rounded-xl overflow-hidden border border-gray-100 aspect-video">
              <iframe
                title="School location"
                className="w-full h-full"
                loading="lazy"
                src={`https://www.google.com/maps?q=${contact!.map_lat},${contact!.map_lng}&z=15&output=embed`}
              />
            </div>
          )}
        </div>

        <div>
          <h2 className="text-lg font-semibold text-husss-green-950 mb-5">
            Send a Message
          </h2>
          <ContactForm />
        </div>
      </div>
    </div>
  );
}
