import { createClient } from "@/lib/supabase/server";
import PageHero from "@/components/public/page-hero";
import { Trophy, Medal, Star } from "lucide-react";

const CATEGORY_LABELS: Record<string, string> = {
  award: "Award",
  exam_result: "Exam Result",
  ranking: "Ranking",
  recognition: "Recognition",
};

export default async function AccomplishmentsPage() {
  const supabase = await createClient();
  const [{ data: accomplishments }, { data: topStudents }] = await Promise.all([
    supabase.from("accomplishments").select("*").order("year", { ascending: false }).order("sort_order"),
    supabase.from("top_students").select("*").order("exam_year", { ascending: false }).order("rank"),
  ]);

  const years = Array.from(new Set((topStudents || []).map((s) => s.exam_year))).sort(
    (a, b) => b - a
  );

  return (
    <div>
      <PageHero
        icon={<Trophy size={28} />}
        eyebrow="Recognition"
        title="Accomplishments"
        subtitle="Exam results, awards, and recognitions that reflect HUSSS’s track record of excellence."
      />

      {/* Top students by year */}
      {years.length > 0 && (
        <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
          <h2 className="text-2xl font-semibold text-husss-green-950 gold-underline inline-block mb-10">
            Top EUEE Grade 12 Scorers
          </h2>
          {years.map((year) => {
            const students = (topStudents || []).filter((s) => s.exam_year === year);
            return (
              <div key={year} className="mb-12">
                <h3 className="text-sm font-semibold text-husss-green-800 mb-4">
                  {year} / {year + 1}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {students.map((student) => (
                    <div
                      key={student.id}
                      className="bg-white rounded-xl border border-gray-100 shadow-sm p-6 text-center"
                    >
                      <div className="w-20 h-20 rounded-full bg-husss-green-50 mx-auto overflow-hidden mb-4 flex items-center justify-center">
                        {student.photo_url ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img src={student.photo_url} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <Medal
                            className={
                              student.rank === 1
                                ? "text-husss-gold-500"
                                : student.rank === 2
                                ? "text-gray-400"
                                : "text-amber-700"
                            }
                            size={28}
                          />
                        )}
                      </div>
                      <p className="text-xs font-medium text-husss-gold-600 mb-1">
                        Rank {student.rank}
                      </p>
                      <p className="font-semibold text-husss-green-950">
                        {student.full_name}
                      </p>
                      {student.score && (
                        <p className="text-sm text-gray-500 mt-1">{student.score}</p>
                      )}
                      {student.quote_en && (
                        <p className="text-sm text-gray-500 italic mt-3">
                          &ldquo;{student.quote_en}&rdquo;
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </section>
      )}

      {/* Accomplishments grid */}
      <section className="bg-husss-green-50 py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <h2 className="text-2xl font-semibold text-husss-green-950 gold-underline inline-block mb-10">
            Awards & Recognitions
          </h2>

          {(!accomplishments || accomplishments.length === 0) && (
            <p className="text-gray-400 italic">
              Accomplishments will appear here as they are added.
            </p>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {(accomplishments || []).map((item) => (
              <div
                key={item.id}
                className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden"
              >
                <div className="aspect-video bg-gray-100">
                  {item.image_url && (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={item.image_url} alt="" className="w-full h-full object-cover" />
                  )}
                </div>
                <div className="p-5">
                  <span className="inline-flex items-center gap-1 text-xs font-medium text-husss-green-700 bg-husss-green-100 rounded-full px-2.5 py-1">
                    <Star size={11} /> {CATEGORY_LABELS[item.category] || item.category}
                  </span>
                  {item.stat_value && (
                    <p className="text-2xl font-bold text-husss-green-700 mt-3">
                      {item.stat_value}
                    </p>
                  )}
                  <p className="font-medium text-husss-green-950 mt-1">{item.title_en}</p>
                  {item.description_en && (
                    <p className="text-sm text-gray-500 mt-1.5">{item.description_en}</p>
                  )}
                  {item.year && (
                    <p className="text-xs text-gray-400 mt-2">{item.year}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
