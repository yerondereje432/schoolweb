import { createClient } from "@/lib/supabase/server";
import PageHero from "@/components/public/page-hero";
import { GraduationCap, Target, Eye, BookOpen, Award } from "lucide-react";

export default async function AboutPage() {
  const supabase = await createClient();
  const { data } = await supabase.from("about_content").select("*").eq("id", 1).single();

  const isPlaceholder = !data?.mission_en && !data?.vision_en && !data?.history_en;

  return (
    <div>
      <PageHero
        icon={<GraduationCap size={30} />}
        eyebrow="About HUSSS"
        title="About HUSSS"
        subtitle="Grades 9–12 · A legacy of academic excellence and strong results in the Ethiopian University Entrance Examination."
      />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-16 space-y-14">
        {isPlaceholder && (
          <div className="bg-husss-gold-100 border border-husss-gold-400 text-husss-gold-700 text-sm rounded-lg px-4 py-3">
            <strong>Placeholder notice:</strong> Mission, vision, and history
            text have not been added yet. A director can fill this in from{" "}
            <span className="font-medium">Admin → Mission &amp; About</span>.
          </div>
        )}

        <section>
          <div className="flex items-center gap-2 mb-3">
            <Target className="text-husss-green-600" size={22} />
            <h2 className="text-xl font-semibold text-husss-green-950">Our Mission</h2>
          </div>
          <p className="text-gray-600 leading-relaxed">
            {data?.mission_en ||
              "Mission statement to be added by school administration."}
          </p>
        </section>

        <section>
          <div className="flex items-center gap-2 mb-3">
            <Eye className="text-husss-green-600" size={22} />
            <h2 className="text-xl font-semibold text-husss-green-950">Our Vision</h2>
          </div>
          <p className="text-gray-600 leading-relaxed">
            {data?.vision_en ||
              "Vision statement to be added by school administration."}
          </p>
        </section>

        <section>
          <div className="flex items-center gap-2 mb-3">
            <BookOpen className="text-husss-green-600" size={22} />
            <h2 className="text-xl font-semibold text-husss-green-950">Our History</h2>
          </div>
          <p className="text-gray-600 leading-relaxed whitespace-pre-line">
            {data?.history_en ||
              "History content to be added by school administration."}
          </p>
        </section>

        <section className="bg-husss-green-50 rounded-2xl p-8">
          <div className="flex items-center gap-2 mb-3">
            <Award className="text-husss-green-600" size={22} />
            <h2 className="text-xl font-semibold text-husss-green-950">
              Why HUSSS Is Distinguished
            </h2>
          </div>
          <p className="text-gray-600 leading-relaxed">
            {data?.why_distinguished_en ||
              "HUSSS serves students in Grades 9 through 12 and is recognized as one of the most accomplished schools in its locality, particularly for its strong results in the Ethiopian University Entrance Examination (EUEE)."}
          </p>
        </section>
      </div>
    </div>
  );
}
