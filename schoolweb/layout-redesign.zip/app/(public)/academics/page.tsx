import { createClient } from "@/lib/supabase/server";
import PageHero from "@/components/public/page-hero";
import { GraduationCap, BookOpen } from "lucide-react";

const STREAM_LABELS: Record<string, string> = {
  natural_science: "Natural Science",
  social_science: "Social Science",
};

export default async function AcademicsPage() {
  const supabase = await createClient();
  const { data: programs } = await supabase
    .from("academic_programs")
    .select("*")
    .order("grade_level")
    .order("sort_order");

  const grouped = (programs || []).reduce<Record<string, typeof programs>>(
    (acc, p) => {
      acc[p.grade_level] = acc[p.grade_level] || [];
      acc[p.grade_level]!.push(p);
      return acc;
    },
    {}
  );

  return (
    <div>
      <PageHero
        icon={<GraduationCap size={30} />}
        eyebrow="Curriculum"
        title="Academics"
        subtitle="HUSSS serves Grades 9 through 12, following the Ethiopian national curriculum with Natural Science and Social Science streams in Grades 11–12."
      />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-16">
        {Object.keys(grouped).length === 0 && (
          <p className="text-gray-400 italic">
            Academic program details will appear here once added by school
            administration.
          </p>
        )}

        <div className="space-y-10">
          {["9", "10", "11", "12"].map((grade) => {
            const entries = grouped[grade];
            if (!entries || entries.length === 0) return null;
            return (
              <div key={grade}>
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-9 h-9 rounded-lg bg-husss-green-600 text-white flex items-center justify-center text-sm font-bold">
                    {grade}
                  </div>
                  <h2 className="text-lg font-semibold text-husss-green-950">
                    Grade {grade}
                  </h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {entries.map((program) => (
                    <div
                      key={program.id}
                      className="bg-white rounded-xl border border-gray-100 shadow-sm p-5"
                    >
                      {program.stream && (
                        <span className="inline-block text-xs font-medium text-husss-green-700 bg-husss-green-100 rounded-full px-2.5 py-1 mb-2">
                          {STREAM_LABELS[program.stream] || program.stream}
                        </span>
                      )}
                      <p className="font-medium text-husss-green-950">
                        {program.title_en}
                      </p>
                      {program.description_en && (
                        <p className="text-sm text-gray-500 mt-1.5">
                          {program.description_en}
                        </p>
                      )}
                      {program.subjects_en && program.subjects_en.length > 0 && (
                        <div className="flex items-start gap-2 mt-3 text-sm text-gray-600">
                          <BookOpen size={15} className="mt-0.5 text-husss-green-500 shrink-0" />
                          <span>{program.subjects_en.join(", ")}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
