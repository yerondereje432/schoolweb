import { createClient } from "@/lib/supabase/server";
import PageHero from "@/components/public/page-hero";
import { Users, Crown } from "lucide-react";

export default async function StaffPage() {
  const supabase = await createClient();
  const { data: staff } = await supabase
    .from("staff_members")
    .select("*")
    .order("is_leadership", { ascending: false })
    .order("sort_order");

  const leadership = (staff || []).filter((s) => s.is_leadership);
  const others = (staff || []).filter((s) => !s.is_leadership);

  return (
    <div>
      <PageHero
        icon={<Users size={28} />}
        eyebrow="Our People"
        title="Staff & Leadership"
        subtitle="The educators and administrators guiding HUSSS students toward excellence."
      />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-16">
        {leadership.length > 0 && (
          <div className="mb-14">
            <h2 className="text-xl font-semibold text-husss-green-950 gold-underline inline-block mb-8">
              Leadership
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {leadership.map((person) => (
                <div
                  key={person.id}
                  className="bg-white rounded-xl border border-gray-100 shadow-sm p-6 flex gap-4 items-center"
                >
                  <div className="w-20 h-20 rounded-full bg-husss-green-50 overflow-hidden shrink-0 flex items-center justify-center">
                    {person.photo_url ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={person.photo_url} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <Crown className="text-husss-gold-500" size={26} />
                    )}
                  </div>
                  <div>
                    <p className="font-semibold text-husss-green-950">{person.full_name}</p>
                    <p className="text-sm text-husss-green-700">{person.role_en}</p>
                    {person.bio_en && (
                      <p className="text-sm text-gray-500 mt-1.5">{person.bio_en}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {others.length > 0 && (
          <div>
            <h2 className="text-xl font-semibold text-husss-green-950 gold-underline inline-block mb-8">
              Teachers & Staff
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
              {others.map((person) => (
                <div key={person.id} className="text-center">
                  <div className="w-20 h-20 rounded-full bg-husss-green-50 overflow-hidden mx-auto mb-3 flex items-center justify-center">
                    {person.photo_url ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={person.photo_url} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <Users className="text-husss-green-300" size={22} />
                    )}
                  </div>
                  <p className="font-medium text-husss-green-950 text-sm">{person.full_name}</p>
                  <p className="text-xs text-gray-500">{person.role_en}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {leadership.length === 0 && others.length === 0 && (
          <p className="text-gray-400 italic">
            Staff and leadership profiles will appear here once added.
          </p>
        )}
      </div>
    </div>
  );
}
