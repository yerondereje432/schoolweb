import Link from "next/link";
import PageHero from "@/components/public/page-hero";
import { createClient } from "@/lib/supabase/server";
import { Images } from "lucide-react";

export default async function GalleryPage() {
  const supabase = await createClient();
  const { data: albums } = await supabase
    .from("gallery_albums")
    .select("*, gallery_images(count)")
    .order("sort_order");

  return (
    <div>
      <PageHero
        icon={<Images size={28} />}
        eyebrow="Student Life"
        title="Student Life & Gallery"
        subtitle="A look at life at HUSSS — classrooms, exams, ceremonies, and more."
      />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        {(!albums || albums.length === 0) && (
          <p className="text-gray-400 italic">
            Photo albums will appear here once added.
          </p>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {(albums || []).map((album) => (
            <Link
              key={album.id}
              href={`/gallery/${album.id}`}
              className="group rounded-xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="aspect-video bg-husss-green-50">
                {album.cover_image_url && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={album.cover_image_url}
                    alt=""
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                )}
              </div>
              <div className="p-4">
                <p className="font-medium text-husss-green-950">{album.title_en}</p>
                {album.description_en && (
                  <p className="text-sm text-gray-500 mt-1 line-clamp-1">
                    {album.description_en}
                  </p>
                )}
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
