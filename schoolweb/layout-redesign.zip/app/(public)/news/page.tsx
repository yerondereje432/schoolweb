import Link from "next/link";
import PageHero from "@/components/public/page-hero";
import { createClient } from "@/lib/supabase/server";
import { Newspaper } from "lucide-react";

// Always render fresh from Supabase — see app/(public)/page.tsx for why.
export const dynamic = "force-dynamic";
export const fetchCache = "force-no-store";
export const revalidate = 0;

export default async function NewsListPage() {
  const supabase = await createClient();
  const { data: posts } = await supabase
    .from("news_posts")
    .select("*, news_categories(name_en)")
    .eq("is_published", true)
    .order("published_at", { ascending: false });

  return (
    <div>
      <PageHero
        icon={<Newspaper size={28} />}
        eyebrow="Bulletin"
        title="News & Announcements"
        subtitle="Stay up to date with what’s happening at HUSSS."
      />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-16">
        {(!posts || posts.length === 0) && (
          <p className="text-gray-400 italic">
            No news posted yet. Check back soon.
          </p>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {(posts || []).map((post) => (
            <Link
              key={post.id}
              href={`/news/${post.slug}`}
              className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden hover:shadow-md transition-shadow"
            >
              <div className="aspect-video bg-gray-100">
                {post.cover_image_url && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={post.cover_image_url} alt="" className="w-full h-full object-cover" />
                )}
              </div>
              <div className="p-5">
                <div className="flex items-center gap-2 text-xs text-gray-400">
                  <span>
                    {post.published_at
                      ? new Date(post.published_at).toLocaleDateString()
                      : ""}
                  </span>
                  {post.news_categories && (
                    <>
                      <span>·</span>
                      <span className="text-husss-green-700 font-medium">
                        {(post.news_categories as { name_en: string }).name_en}
                      </span>
                    </>
                  )}
                </div>
                <p className="font-semibold text-husss-green-950 mt-1.5">
                  {post.title_en}
                </p>
                {post.excerpt_en && (
                  <p className="text-sm text-gray-500 mt-1.5 line-clamp-2">
                    {post.excerpt_en}
                  </p>
                )}
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
