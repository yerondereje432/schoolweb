import { createClient } from "@/lib/supabase/server";
import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";

// Always render fresh from Supabase — see app/(public)/page.tsx for why.
export const dynamic = "force-dynamic";
export const fetchCache = "force-no-store";
export const revalidate = 0;

export default async function NewsDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const supabase = await createClient();
  const { data: post } = await supabase
    .from("news_posts")
    .select("*, news_categories(name_en)")
    .eq("slug", slug)
    .eq("is_published", true)
    .single();

  if (!post) notFound();

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
      <Link
        href="/news"
        className="inline-flex items-center gap-1.5 text-sm text-husss-green-700 hover:underline mb-6"
      >
        <ArrowLeft size={14} /> Back to News
      </Link>

      {post.cover_image_url && (
        <div className="aspect-video rounded-xl overflow-hidden bg-gray-100 mb-6">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={post.cover_image_url} alt="" className="w-full h-full object-cover" />
        </div>
      )}

      <div className="flex items-center gap-2 text-xs text-gray-400 mb-2">
        <span>{post.published_at ? new Date(post.published_at).toLocaleDateString() : ""}</span>
        {post.news_categories && (
          <>
            <span>·</span>
            <span className="text-husss-green-700 font-medium">
              {(post.news_categories as { name_en: string }).name_en}
            </span>
          </>
        )}
      </div>

      <h1 className="text-2xl md:text-3xl font-bold text-husss-green-950 mb-6">
        {post.title_en}
      </h1>

      <div className="prose prose-green max-w-none text-gray-700 whitespace-pre-line leading-relaxed">
        {post.body_en || post.excerpt_en || ""}
      </div>
    </div>
  );
}
