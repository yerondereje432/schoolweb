"use client";

import { useRef, type ReactNode } from "react";

/**
 * Interior-page hero banner. Carries the same deep-green ground and gold
 * seal language as the homepage, but here the badge is a real 3D object:
 * a layered, perspective-tilted disc that responds to the cursor, built
 * from CSS transforms only (no 3D library / no extra dependency).
 *
 * Falls back to a static tilt on touch devices and is fully inert under
 * prefers-reduced-motion (handled in globals.css via the .tilt-badge rule).
 */
export default function PageHero({
  icon,
  eyebrow,
  title,
  subtitle,
}: {
  icon: ReactNode;
  eyebrow: string;
  title: string;
  subtitle: string;
}) {
  const stageRef = useRef<HTMLDivElement>(null);
  const badgeRef = useRef<HTMLDivElement>(null);

  function handleMove(e: React.MouseEvent<HTMLDivElement>) {
    const stage = stageRef.current;
    const badge = badgeRef.current;
    if (!stage || !badge) return;

    const rect = stage.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width - 0.5;
    const py = (e.clientY - rect.top) / rect.height - 0.5;

    badge.style.transform = `rotateY(${px * 26}deg) rotateX(${-py * 26}deg) translateZ(12px)`;
  }

  function handleLeave() {
    const badge = badgeRef.current;
    if (!badge) return;
    badge.style.transform = "rotateY(0deg) rotateX(0deg) translateZ(0px)";
  }

  return (
    <section className="relative bg-husss-green-950 text-white py-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-husss-green-900/40 via-transparent to-husss-green-950" />
      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 flex flex-col items-center text-center">
        <div
          ref={stageRef}
          onMouseMove={handleMove}
          onMouseLeave={handleLeave}
          className="tilt-stage mb-6"
        >
          <div ref={badgeRef} className="tilt-badge">
            <div className="tilt-badge-face">
              <div className="tilt-badge-ring" />
              <div className="tilt-badge-icon">{icon}</div>
            </div>
            <div className="tilt-badge-edge" aria-hidden />
          </div>
        </div>

        <span className="eyebrow text-husss-gold-400">{eyebrow}</span>
        <h1 className="font-display mt-3 text-3xl md:text-[2.75rem] font-semibold leading-tight">
          {title}
        </h1>
        <p className="text-white/65 mt-4 max-w-xl leading-relaxed">{subtitle}</p>
      </div>
    </section>
  );
}
